\set ON_ERROR_STOP on
DO $verify$
BEGIN
  IF (SELECT count(*) FROM public."customers") <> 3 THEN RAISE EXCEPTION 'Row count mismatch: customers'; END IF;
  IF (SELECT count(*) FROM public."order_items") <> 6 THEN RAISE EXCEPTION 'Row count mismatch: order_items'; END IF;
  IF (SELECT count(*) FROM public."orders") <> 4 THEN RAISE EXCEPTION 'Row count mismatch: orders'; END IF;
  IF (SELECT count(*) FROM public."products") <> 4 THEN RAISE EXCEPTION 'Row count mismatch: products'; END IF;
END;
$verify$;
