BEGIN;
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'UTC';
INSERT INTO public."order_items" ("order_id", "product_id", "quantity", "unit_price_minor") VALUES
(1001, 101, 2, 12500),
(1001, 102, 1, 89000),
(1002, 103, 3, 5000),
(1003, 102, 1, 89000),
(1004, 104, 10, 0),
(1004, 101, 1, 12500);
COMMIT;
