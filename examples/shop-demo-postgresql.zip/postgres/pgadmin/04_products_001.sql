BEGIN;
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'UTC';
INSERT INTO public."products" ("id", "title", "price_minor", "active", "attributes") VALUES
(101, 'Блокнот A + B', 12500, TRUE, '{"color":"blue","tags":["paper","A+B"]}'),
(102, 'Кружка', 89000, TRUE, '{"volume_ml":350}'),
(103, 'Подарочный пакет', 5000, FALSE, '{}'),
(104, 'Наклейка', 0, TRUE, '{"text":"Строка\nс переносом"}');
COMMIT;
