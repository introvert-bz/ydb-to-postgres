BEGIN;
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'UTC';
INSERT INTO public."customers" ("id", "name", "email", "created_at") VALUES
(1, 'Покупатель Альфа', 'alpha@example.invalid', '2026-01-01T10:00:00.123456+00:00'),
(2, 'Покупатель Бета', NULL, '2026-01-02T11:00:00+00:00'),
(3, 'Demo O''Brien', 'demo@example.invalid', '2026-01-03T12:00:00+00:00');
COMMIT;
