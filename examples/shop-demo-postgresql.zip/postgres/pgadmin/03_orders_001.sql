BEGIN;
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'UTC';
INSERT INTO public."orders" ("id", "customer_id", "status", "placed_at", "note") VALUES
(1001, 1, 'paid', '2026-02-01T10:15:00+00:00', NULL),
(1002, 2, 'draft', '2026-02-02T12:00:00+00:00', ''),
(1003, 3, 'shipped', '2026-02-03T15:30:00+00:00', 'null'),
(1004, 1, 'paid', '2026-02-04T09:00:00+00:00', 'A + B
Вторая строка	O''Brien\N');
COMMIT;
