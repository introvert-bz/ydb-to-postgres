\set ON_ERROR_STOP on
SET client_encoding = 'UTF8';
BEGIN;
SET LOCAL TIME ZONE 'UTC';
SET LOCAL search_path = public;
COPY public."customers" ("id", "name", "email", "created_at") FROM STDIN WITH (FORMAT text);
1	Покупатель Альфа	alpha@example.invalid	2026-01-01T10:00:00.123456+00:00
2	Покупатель Бета	\N	2026-01-02T11:00:00+00:00
3	Demo O'Brien	demo@example.invalid	2026-01-03T12:00:00+00:00
\.
COPY public."order_items" ("order_id", "product_id", "quantity", "unit_price_minor") FROM STDIN WITH (FORMAT text);
1001	101	2	12500
1001	102	1	89000
1002	103	3	5000
1003	102	1	89000
1004	104	10	0
1004	101	1	12500
\.
COPY public."orders" ("id", "customer_id", "status", "placed_at", "note") FROM STDIN WITH (FORMAT text);
1001	1	paid	2026-02-01T10:15:00+00:00	\N
1002	2	draft	2026-02-02T12:00:00+00:00	
1003	3	shipped	2026-02-03T15:30:00+00:00	null
1004	1	paid	2026-02-04T09:00:00+00:00	A + B\nВторая строка\tO'Brien\\N
\.
COPY public."products" ("id", "title", "price_minor", "active", "attributes") FROM STDIN WITH (FORMAT text);
101	Блокнот A + B	12500	t	{"color":"blue","tags":["paper","A+B"]}
102	Кружка	89000	t	{"volume_ml":350}
103	Подарочный пакет	5000	f	{}
104	Наклейка	0	t	{"text":"Строка\\nс переносом"}
\.
COMMIT;
