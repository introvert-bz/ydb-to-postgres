\set ON_ERROR_STOP on
SET search_path = public;
\ir 001_initial_schema.sql
\ir data.sql
