BEGIN;

SET LOCAL search_path = public;

CREATE TABLE public."customers" (
    "id" BIGINT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL,
    PRIMARY KEY ("id")
);

CREATE TABLE public."order_items" (
    "order_id" BIGINT NOT NULL,
    "product_id" BIGINT NOT NULL,
    "quantity" BIGINT NOT NULL,
    "unit_price_minor" BIGINT NOT NULL,
    PRIMARY KEY ("order_id", "product_id")
);

CREATE TABLE public."orders" (
    "id" BIGINT NOT NULL,
    "customer_id" BIGINT NOT NULL,
    "status" TEXT NOT NULL,
    "placed_at" TIMESTAMPTZ NOT NULL,
    "note" TEXT,
    PRIMARY KEY ("id")
);

CREATE TABLE public."products" (
    "id" BIGINT NOT NULL,
    "title" TEXT NOT NULL,
    "price_minor" BIGINT NOT NULL,
    "active" BOOLEAN NOT NULL,
    "attributes" JSONB NOT NULL,
    PRIMARY KEY ("id")
);

CREATE INDEX "orders_by_customer" ON public."orders" ("customer_id");

ALTER TABLE public."customers" ADD CHECK ("id" BETWEEN 0 AND 4294967295);

ALTER TABLE public."order_items" ADD CHECK ("order_id" BETWEEN 0 AND 4294967295);

ALTER TABLE public."order_items" ADD CHECK ("product_id" BETWEEN 0 AND 4294967295);

ALTER TABLE public."order_items" ADD CHECK ("quantity" BETWEEN 0 AND 4294967295);

ALTER TABLE public."orders" ADD CHECK ("id" BETWEEN 0 AND 4294967295);

ALTER TABLE public."orders" ADD CHECK ("customer_id" BETWEEN 0 AND 4294967295);

ALTER TABLE public."products" ADD CHECK ("id" BETWEEN 0 AND 4294967295);

COMMIT;
