columns { name: "id" type { type_id: UINT32 } }
columns { name: "customer_id" type { type_id: UINT32 } }
columns { name: "status" type { type_id: UTF8 } }
columns { name: "placed_at" type { type_id: DATETIME } }
columns { name: "note" type { optional_type { item { type_id: UTF8 } } } }
primary_key: "id"
indexes { name: "by_customer" index_columns: "customer_id" global_index {} }
