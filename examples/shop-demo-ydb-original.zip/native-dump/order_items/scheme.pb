columns { name: "order_id" type { type_id: UINT32 } }
columns { name: "product_id" type { type_id: UINT32 } }
columns { name: "quantity" type { type_id: UINT32 } }
columns { name: "unit_price_minor" type { type_id: INT64 } }
primary_key: "order_id"
primary_key: "product_id"
