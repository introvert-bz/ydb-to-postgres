columns { name: "id" type { type_id: UINT32 } }
columns { name: "name" type { type_id: UTF8 } }
columns { name: "email" type { optional_type { item { type_id: UTF8 } } } }
columns { name: "created_at" type { type_id: TIMESTAMP } }
primary_key: "id"
