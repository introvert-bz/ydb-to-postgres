columns { name: "id" type { type_id: UINT32 } }
columns { name: "title" type { type_id: UTF8 } }
columns { name: "price_minor" type { type_id: INT64 } }
columns { name: "active" type { type_id: BOOL } }
columns { name: "attributes" type { type_id: JSON_DOCUMENT } }
primary_key: "id"
